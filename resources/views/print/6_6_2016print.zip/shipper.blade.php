<!DOCTYPE html>
<html moznomarginboxes mozdisallowselectionprint>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel='stylesheet' type='text/css' media="all" href="{{url('public/shippingtemplate/css/print-table/reset.css')}}" />
<link rel="stylesheet" type="text/css" media="all" href="{{url('public/shippingtemplate/css/print-table/style.css')}}" />
    <title>SHIPPER'S EXPORT DECLARATION</title>
    <!-- Description, Keywords and Author -->
    <meta name="description" content="SERENCO JSC" />
    <meta name="keywords" content="CORE BANKING, BANKING SOFTWARE" />
    <meta name="author" content="serenco jsc">
    <style type="text/css">
        @media print {
            @page {
                size: landscape
            }
            body {
                font-size: 11px;
            }
            p {
                font-size: 8px;
            }
            @page {
                size: A4 landscape;
                margin: 0 0.5cm;
                position: relative;
            }
            #page-wrap {
                width: 100%;
                margin: 0.2cm auto;
            }
            table#test p {
                line-height: 13px;
            }
            table {
            border-collapse: collapse;
            border-spacing: 0px 0px;
            }
            table td, table th {
                padding: 2pt;
                border-collapse: collapse;
                border-spacing: 0px 0px;
            }
        
        }
    </style>
</head>

<body>
    <div id="page-wrap">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td colspan="5" class="reset-padding-all">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr >
                            <td width="75%" class="reset-padding-all border_bottom">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr class="border_bottom">
                                        <td width="65%" class="reset-padding-all border_right">
                                            <p class="fix-tex-zise">U.S DEPARTMENT OF COMMERCE<samp> -BUREAU OF THE CEN CUS - INTERNATIONAL TRADE ADMINISTRATION</samp>
                                            </p>
                                            <p><samp style ="font-size: 11px">FORM </samp><samp class= "fix-tex-zise">7525-V-ALT.(Intermodal) (1-1-88) </samp> <strong style ="font-size: 14px"> SHIPPER'S EXPORT DECLARATION </strong> </p>
                                        </td>
                                        <td width="35%" class="reset-padding-all">
                                        <p><strong style ="font-size: 12px">CONFIDENTAL </strong> <samp class="fix-tex-zise">- For use solely offical purposes</samp>
                                            </p>
                                            <p>authorized by the Secretary of Commerce (13 U.S.C 301(g)).</p>
                                        </td>
                                    </tr>


                                    <tr class="border_bottom">
                                        <td class="reset-padding-all" colspan="2">


                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td rowspan="2" scope="row" width="50%" class="reset-padding-all border_right">
                                                        <p>EXPORTER (Principal or Seller- lisence and address including ZIP Code)</p>
                                                        <p class="blue_acl">
                                                        <?php 
                                                        $str =$showbook->exporter;                  
                                                        $a= strpos($str,'Company:');
                                                        $b= strpos($str,'Address:');                        
                                                        echo substr($str,$a+8,$b-$a-8)."<br>";

                                                        $a2 = strpos($str,'Address:');
                                                        $b2= strpos($str,'City:');  
                                                        echo substr($str,$a2+8,$b2-$a2-8)."<br>";

                                                        $a3 = strpos($str,'City:');
                                                        $b3= strpos($str,'State:'); 
                                                        echo substr($str,$a3+5,$b3-$a3-5);

                                                        $a4 = strpos($str,'State:');
                                                        $b4= strpos($str,'Zip');    
                                                        echo substr($str,$a4+6,$b4-$a4-6);

                                                        $a5 = strpos($str,'Zip Code:');
                                                        $b5= strpos($str,'Country');    
                                                        echo substr($str,$a5+9,$b5-$a5-9);

                                                        $a6 = strpos($str,'Country:');
                                                        $b6= strpos($str,'Tel');    
                                                        echo substr($str,$a6+8,$b6-$a6-8);

                                                        $a7 = strpos($str,'Tel:');
                                                        $b7= strpos($str,'Fax');    
                                                        echo substr($str,$a7,$b7-$a7);
                                                            
                                                        $a8= strpos($str,'Fax:');                       
                                                        echo substr($str,$a8,strlen($str)-$a8);                         
                                                        ?>
                                                    </p>
                                                    </td>
                                                    <td class="reset-padding-all border_right">
                                                        <p>BOOKING NUMBER </p>
                                                        <p class="blue_acl">{{$showbook->booking_no}}</p>
                                                    </td>
                                                    <td class="reset-padding-all">
                                                        <P>B/L OR AWB NUMBER</P>
                                                        <p class="blue_acl">{{$showbook->BL_no}}</p>
                                                    </td>
                                                </tr>
                                                <tr class="border_top">
                                                    <td colspan="2" class="reset-padding-all">
                                                        <P>EXPORT REFERENCES</P>
                                                        <p class="blue_acl">{{$showbook->export_ref}}</p>

                                                    </td>
                                                </tr>
                                            </table>

                                        </td>
                                    </tr>

                                    <tr class="border_bottom">
                                        <td class="reset-padding-all" colspan="2">



                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td rowspan="2" scope="row" class="reset-padding-all border_right" width="50%">
                                                        <p>CONSIGNED TO </p>
                                                            <p style="white-space: pre-wrap;" class="blue_acl">{{$showbook->delivery }}      
                                                          </p>

                                                    </td>
                                                    <td class="reset-padding-all border_bottom">
                                                        <p>FORWARDING AGENT (Name and Address - references)</p>
                                                        <p>&nbsp;</p>
                                                        <p>&nbsp;</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="reset-padding-all">
                                                            <P>POINT (STATE) OF ORIGIN OR FTZ NUMBER</P> 
                                                            <p> &nbsp;</p>
                                                    </td>
                                                </tr>
                                            </table>

                                        </td>
                                    </tr>



                                    <tr class="border_bottom">
                                        <td class="reset-padding-all" colspan="2">


                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td colspan="2" scope="row" class="reset-padding-all border_bottom" width="50%">
                                                        <p>NOTIFY PARTY/INTERMEDIATE CONSIGNEE(Name and address)</p>
                                                            <p>(SAME AS CONSIGNEE)</p>

                                                    </td>
                                                    <td width="50%" rowspan="2" class="reset-padding-all border_left">
                                                       <P>DOMESTIC ROUTING/EXPORT INSTRUCTIONS</P>
                                                                                                
                                                        <P class="blue_acl" style="white-space: pre-wrap;"><?php echo $showbook->domestic_routing ?>
                                                        </P>
                                                    </td>



                                                </tr>
                                                <tr>
                                                    <td width="25%" class="reset-padding-all border_right" scope="row">
                                                        <P>PRE-CARRIAGE BY</P>
                                                    </td>
                                                    <td class="reset-padding-all" width="25%">
                                                        <P>PLACE OF RECEIPT BY PRE-CARRIER</P>
                                                        <P class="blue_acl">{{$showbook->place_receipt }}</P>
                                                    </td>
                                                </tr>
                                            </table>

                                        </td>
                                    </tr>



                                    <tr class="border_bottom">
                                        <td class="reset-padding-all" colspan="2">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>


                                                    <td width="25%" class="reset-padding-all border_right">
                                                        <p>EXPORTING CARRIER</p>
                                                        <p class="blue_acl">{{$showbook->export_carrier }}</p>
                                                    </td>
                                                    <td width="25%" class="reset-padding-all ">
                                                        <p>PORT OF LOADING/EXPORT</p>
                                                        <p class="blue_acl">{{$showbook->place_receipt}} </p>
                                                    </td>


                                                    <td width="50%" class="reset-padding-all border_left">
                                                        <P>LOADING PIER/TERMINAL</P>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>



                                    <tr class="border_bottom">
                                        <td class="reset-padding-all" colspan="2">
                                        
                                        
                                        
                                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                  <tr>
                                                    <td rowspan="2" scope="row" class = "reset-padding-all border_right" width = "25%"> <p>FOREIGN PORT OF UNLOADING (Vessel and Air only)</p>
                                                    </td>
                                                    <td rowspan="2" class = "reset-padding-all border_right" width = "25%"> <p>PLACE OF DELIVERY BY ON-CARRIER</p>
                                                        <p class="blue_acl">{!! $showbook->final_dest !!}</p></td>
                                                    <td width  = "25%"rowspan="2" class = "reset-padding-all border_right"> <p>TYPE OF MOVE</p>
                                                        <p class="blue_acl">{{$showbook->type_move}}</p></td>
                                                    <td colspan="2" width = "25%" class = "reset-padding-all">  <p>CONTAINERIZED (Vessel only)</p></td>
                                                  </tr>
                                                  <tr>
                                                    <td class = "reset-padding-all"><p>
                                                                    <input type="checkbox" value="yes" <?php if ($showbook->containerized == 'Yes'): ?>checked='checked'<?php endif; ?> disabled=""> Yes</p>
                                                                    </td>
                                                    <td class = "reset-padding-all"><p>
                                                                        <input type="checkbox" value="no" <?php if ($showbook->containerized == 'No'): ?>checked='checked'<?php endif; ?> disabled=""> No
                                                                    </p>
                                                                   </td>
                                                  </tr>
                                            </table>
                                            
                                            
                                            
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="reset-padding-all" colspan="2">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td class="reset-padding-all border_right" width="14%">
                                                        <p>MARKS AND NUMBERS </p>



                                                    </td>
                                                    <td width="11%" align="center" valign="middle" class="reset-padding-all border_right">
                                                        <p>NUMBER OF PACKAGES</p>



                                                    </td>
                                                    <td width="40%" valign="middle" class="reset-padding-all border_right">

                                                        <p>DESCRIPTION OF COMMODITIES in Schedule B detail  </p>
                                                        


                                                    </td>
                                                    <td width="16%" align="left" valign="middle" class="reset-padding-all border_right">

                                                        <p>GROSS WEIGHT(KILOS) </p>


                                                    </td>
                                                    <td width="19%" align="center" valign="middle" class="reset-padding-all">

                                                        <p>MEASUREMENT</p>



                                                    </td>
                                                </tr>

                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td width="25%" class="reset-padding-all border_left">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0" id="test">
                                    <tr>
                                        <td align="center" valign="middle" class="reset-padding-all">
                                            <p class="fix-tex-zise-10">OMB No. </p>
                                        </td>
                                    </tr>

                                    <tr class="border_all">
                                        <td class="reset-padding-all">
                                          
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">AUTHENTICATION (When required)</p>

                                        </td>

                                    </tr>

                                    <tr class="border_bottom">
                                        <td class ="reset-padding-all">
                                            <p class="fix-tex-zise-10">THE UNDERSIGNED HEREBY AUTHORIZES</p>
                                            <p class="fix-tex-zise-10">EXPORTER________________________</p>
                                            <p class="fix-tex-zise-10">(BY DULY AUTHORIZED </p>
                                            <p class="fix-tex-zise-10">OFFICER OR EMPLOYEE)________________________</p>
                                    </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td colspan="2" class ="reset-padding-all">
                                                        <p class="fix-tex-zise-10">METHOD OF TRANSPORTATION (Mark one)</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class = "reset-padding-all">
                                                        <p>
                                                           <input type="checkbox" value="Vessel" <?php if ($showbook->method_trans == 'Vessel'): ?>checked='checked'<?php endif; ?> disabled=""> Vessel</p>
                                                    </td>
                                                    <td width="30%" rowspan="2" valign="middle" class = "reset-padding-all">
                                                        <p>
                                                            <input type="checkbox" value="Other-Speclfys" <?php if ($showbook->method_trans == 'Other - Special'): ?>checked='checked'<?php endif; ?> disabled=""> Other-Specify</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class ="reset-padding-all">
                                                        <p>
                                                            <input type="checkbox" value="Air" <?php if ($showbook->method_trans == 'Air'): ?>checked='checked'<?php endif; ?> disabled=""> Air</p>
                                                    </td>
                                                </tr>

                                            </table>

                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">ULTIMATE CONSIGNEE (Give name and Address if this party is not shown in item 3) </p>
                                        </td>
                                    </tr>

                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">DATE OF EXPORTATION (Not required for vessel shipments)
                                                <font color="#033264"> {{date_format(date_create($showbook->date_export),"m/d/Y") }}</font></p>
                                        </td>
                                    </tr>

                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">COUNTRY OF ULTIMATE DESTINATION</p>
                                            <p class="blue_acl"> {!! $showbook->country_des !!} </p>
                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">EXPORTER'S EIN(IRS) NUMBER  </p>
                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td colspan="2" class ="reset-padding-all">
                                                        <p class="fix-tex-zise-10">METHOD OF TRANSPORTATION 
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td width="50%" class = "reset-padding-all">
                                                        <p>
                                                            <input type="checkbox" value="Related" <?php if ($showbook->parties_trans == 'Related'): ?>checked='checked'<?php endif; ?> disabled=""> Related </p>
                                                    </td>
                                                    <td width="50%" class = "reset-padding-all">
                                                        <p>
                                                            <input type="checkbox" value="Non-Related" <?php if ($showbook->parties_trans == 'Non-Related'): ?>checked='checked'<?php endif; ?> disabled=""> Non-Related</p>
                                                    </td>
                                                </tr>

                                            </table>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="reset-padding-all">
                                             <p>Export shipments are subject to inspection by U.S</p>
                                            <p>Customs Service add/or Office of Export Enforcement</p>
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                </td>


            </tr>





            <tr>
                <td colspan="5" class="reset-padding-all">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td class="reset-padding-all border_right" style ="width:10.5%;">
                                <p>FCL/FCL</p>
                               
                                <p>GRSD3437584</p>

                            </td>
                            <td class="reset-padding-all border_right" style ="width:8.25%;">

                               

                                <p class="blue_acl">{{$showbook->package_no}} </p>


                            </td>
                            <td class="reset-padding-all border_right" style ="width:30%;"  ><p >
                                 <pre class="blue_acl" style="white-space: pre-wrap;">{{$showbook->kind_package_no}}</pre>
                                </p>

                            </td>
                            <td class="reset-padding-all border_right" style ="width:12%;">

                                <p class="blue_acl">{{$showbook->gross_weight}}</p>

                            </td>
                            <td class="reset-padding-all" style="width:14.25%;">


                                <p class="blue_acl">{{$showbook->measurement}}</p>


                            </td>
                            <td style = "width:25%;" class="reset-padding-all border_left border_top">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr class="border_bottom">
                                        <td class="reset-padding-all">
                                            <p class="fix-tex-zise-10">CD - Check digit</p>
                                            <p style = "font-size:7px">Value - Selling price or cost if not sold (U.S dollars, omit certs) </p>
                                            <p style = "font-size:7px">Quantity - Schedule B unit(s) (Nearest whole unit)</p>
                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="70%" align="left" valign="top" class ="reset-padding-all">
                                                        <p class="fix-tag-p reset-padding-all">SCHEDULE B NO.</p>
                                                    </td>
                                                    <td width="30%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">CD</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="50%" align="left" valign="top" class = "reset-padding-all"> 
                                                        <p class="fix-tag-p reset-padding-all">QUANTILY 1</p>
                                                    </td>
                                                    <td width="50%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">QUANTILY 2</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class = "reset-padding-all">
                                        <p class="fix-tag-p reset-padding-all">VALUE: <font color="#033264"> {!! $showbook->value !!} </font></p>
                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="70%" align="left" valign="top" class = "reset-padding-all">
                                                        <p class="fix-tag-p reset-padding-all">SCHEDULE B NO.</p>
                                                    </td>
                                                    <td width="30%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">CD</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="50%" align="left" valign="top">
                                                        <p class="fix-tag-p reset-padding-all">QUANTILY 1</p>
                                                    </td>
                                                    <td width="50%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">QUANTILY 2</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class = "reset-padding-all">
                                            <p class="fix-tag-p reset-padding-all">VALUE</p>
                                        </td>
                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="70%" align="left" valign="top" class ="reset-padding-all">
                                                        <p class="fix-tag-p ">SCHEDULE B NO.</p>
                                                    </td>
                                                    <td width="30%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">CD</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr class="border_bottom">
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="50%" align="left" valign="top" class="reset-padding-all">
                                                        <p>QUANTILY 1</p>
                                                    </td>
                                                    <td width="50%" align="left" valign="top" class="border_left reset-padding-all">
                                                        <p class="fix-tag-p">QUANTILY 2</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td align="left" valign="top" class="reset-padding-all">
                                            <p>VALUE</p>
                                        </td>
                                    </tr>
                                </table>

                            </td>

                        </tr>


                    </table>

                </td>
            </tr>

            <tr>
                <td colspan="5" class="reset-padding-all">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td class="reset-padding-all border_bottom border_right" style ="width:10.5%">



                            </td>
                            <td class="reset-padding-all border_right border_bottom" style ="width:8.25%;">



                            </td>
                            <td class="reset-padding-all border_top border_right" style ="width:24%;">

                                <p>VALIDATED LICENSE NO./GENERAL LICENSE SYMBOL</p>

                                <p>G-DEST</p>

                            </td>
                            <td width="6%" align="center" valign="top" class="reset-padding-all border_top">

                                <p>ECCN (When repired)</p>


                            </td>
                            <td class="reset-padding-all border_left border_bottom" style ="width:51.25%;">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td colspan="3" class="reset-padding-all border_top ">
                                            <p class="fix-tex-zise-1">I certify that all statements made and all information contained herein are true and correct and that I have read and understand the instruction for preparation of this document, set forth in the "Correct Way to Fill out the Shipper's Export Declaration."  I understand that civil and criminal penalties, including forfeitrue and sale, may be imposed for making false or fraudulent statements herein, failing to provide the requested information, or for violation of U.S laws on exportation (13 U.S.C sec. 305; 22 U.S.C Sec 401; 18 U.S.C Sec. 1001; 50 U.S.C App. 2410)</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="33%" class="reset-padding-all">
                                            <p>HEATHER</p>
                                        </td>
                                        <td width="33%" class="reset-padding-all">
                                            
                                        </td>
                                        <td width="33%" class="text-right reset-padding-all">
                                            <p class="blue_acl"><?php echo date("m/d/Y"); ?></p>
                                        </td>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                    </table>

                </td>


            </tr>
            <tr>
                <td colspan="5" class = "reset-padding-all">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="43%" class="reset-padding-all">
                                <p>The &quot;Correct Way to Fill out the Shipper's Export Declaration&quot; is vailable from the Bureau of the Census, Washington, D.C.20233.</p>
                            </td>
                            <td width="6%" class = "reset-padding-all"></td>
                            <td width="51%" class="reset-padding-all">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td width="33%" class="reset-padding-all border-left">(Signature)</td>
                                        <td width="33%" class="reset-padding-all ">(Title)</td>
                                        <td width="33%" align="right" class="reset-padding-all">(Date)</td>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

        <input type="button" class="hide" onClick="window.print()" class="hide" value="Print" />
    </div>
</body>

</html>