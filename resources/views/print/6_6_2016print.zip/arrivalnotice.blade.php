<!DOCTYPE html>
<html moznomarginboxes mozdisallowselectionprint>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel='stylesheet' type='text/css' media="all" href="{{url('public/shippingtemplate/css/print-table/reset.css')}}" />
<link rel="stylesheet" type="text/css" media="all" href="{{url('public/shippingtemplate/css/print-table/style.css')}} "/>
<title>ARRIVAL NOTICE/INVOICE</title>
<!-- Description, Keywords and Author -->
<meta name="description" content="SERENCO JSC"/>
<meta name="keywords" content="CORE BANKING, BANKING SOFTWARE"/>
<meta name="author" content="serenco jsc">
<style type="text/css" media="print"> 
p{
	font-size:10px;
}
.footer-print{
	bottom:0.5cm;
}
</style>
</head>

<body>
	<div id="page-wrap">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td><img src="{{url('public/shippingtemplate/images/acl.png')}}" alt="ACL" width="400"/></td>
				</tr>
				<tr>
					<td align="right"><pre>File No.       </pre></td>
				</tr>
				<tr>
					<td align="center"><h1 class="font-bold">ARRIVAL NOTICE/INVOICE</h1></td>
				</tr>
				<tr>
					<td class="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="16%" class="tex-underline"><p>DATE:</p></td>
							<td colspan="2" class="text-uppercase blue_acl"><p class="font-bold">{{date_format(date_create($showbook->today),"m/d/Y") }}</p></td>
							<td width="15%" class="text-uppercase"><p class="tex-underline">MODE: </p></td>
							<td width="8%" class="font-bold blue_acl"><p class="text-uppercase">{{$showbook->mode}}</p></td>
							<td width="10%" class="tex-underline"><p class="text-uppercase">P/U NO. </p></td>
							<td width="10%" class="font-bold blue_acl"><p class="text-uppercase">{{$showbook->PU_no}} </p></td>
						  </tr>
						  <tr>
							<td class=" text-uppercase tex-underline"><p>SHIPPER:</p></td>
							<td colspan="2" class="text-uppercase blue_acl"><p class="font-bold"><?php 								
								$str =$showbook->shipper;					
								$a= strpos($str,'Company:');
								$b= strpos($str,'City:');
								
								echo substr($str,$a+8,$b-$a-8);
						?> </p></td>
							<td class="text-uppercase"><p class="tex-underline">CONSIGNEE:</p></td>
							<td colspan="2" class="font-bold blue_acl"><p class="text-uppercase">
							<?php 
								$str =$showbook->consignee;					
								$a= strpos($str,'Company:');
								$b= strpos($str,'Address:');
								
								echo substr($str,$a+8,$b-$a-8);
							?>
						</p></td>
						  </tr>
						  <tr>
							<td class="tex-underline"><p>Vessel/voyage:</p></td>
							<td colspan="2" class="text-uppercase "><p class="font-bold blue_acl">{{$showbook->vessel}}</p></td>
							<td class="text-uppercase"><p class="tex-underline">master b/l:</p></td>
							<td colspan="2" class="font-bold"><p class="text-uppercase blue_acl">{{$showbook->master_BL}}</p></td>
						  </tr>
						  <tr>
							<td class=" tex-underline text-uppercase "><p>container no:</p></td>
							<td colspan="2" class="text-uppercase blue_acl"><p class="font-bold">{{$showbook->container_no}}</p></td>
							<td class="text-uppercase"><p class="tex-underline">ams b/l:</p></td>
							<td colspan="2" class="font-bold"><p class="text-uppercase blue_acl">{{$showbook->AMS_BL}}</p></td>
						  </tr>
						  <tr>
							<td class="tex-underline"><p>Port of Loading:</p></td>
							<td colspan="2" class="text-uppercase"><p class="font-bold blue_acl">{{$showbook->port_cargo}}</p></td>
							<td class="text-uppercase"><p class="tex-underline">house b/l:</p></td>
							<td colspan="2" class="font-bold"><p class="text-uppercase blue_acl">{{$showbook->House_BL}}</p></td>
						  </tr>
						  <tr>
							<td class="tex-underline"><p>Port of Discharge:</p></td>
							<td colspan="2" class="text-uppercase"><p class="font-bold blue_acl">{{$showbook->port_discharge}}</p></td>
							<td class="text-uppercase"><p class="tex-underline">final dest:</p></td>
							<td colspan="2" class="font-bold blue_acl"><p>{{$showbook->final_dest}}</p></td>
						  </tr>
						  <tr>
							<td class=" tex-underline text-uppercase"><p>e.t.d date: </p></td>
							<td colspan="2" class="text-uppercase"><p class="font-bold blue_acl">{{date_format(date_create($showbook->ETD),"m/d/Y")}}</p></td>							
							<td class="text-uppercase"><p class="tex-underline">final e.t.a:</p></td>
							<td colspan="2" class="font-bold blue_acl"><p>{{$showbook->Final_ETA}}</p></td>
						  </tr>
						  <tr>
							<td class="tex-underline text-uppercase"><p>e.t.a date:</p></td>
							<td colspan="2" class="text-uppercase"><p class="font-bold blue_acl">{{date_format(date_create($showbook->ETA),"m/d/Y")}}</p></td>
							
							<td class="text-uppercase"><p class="tex-underline">I.T No</p></td>
							<td colspan="2" class="font-bold blue_acl"><p>{{$showbook->IT_no}}</p></td>
						  </tr>
						  <tr>
						    <td class=" tex-underline text-uppercase"><p>shipping line:</p></td>
						    <td colspan="2" class="text-uppercase"><p class="font-bold blue_acl"><?php echo $showbook->shipping_line; ?></p>						    	
						    </td>
						    <td class="text-uppercase"><p class="tex-underline">date i.t issued</p></td>
						    <td > <p class="font-bold blue_acl"> {{date_format(date_create($showbook->date_it_issued),"m/d/Y")}}
						    </p>
						   </td>
						   <td width="15%" class="text-uppercase"><p class="tex-underline">last free date:  </p>
						   										<p class="tex-underline">g.o date:  </p>
						   </td>
						   <td width="15%" class="text-uppercase"><p class="font-bold blue_acl">{{date_format(date_create($showbook->last_free_date),"m/d/Y")}} </p>
						   <p class="font-bold blue_acl">{{date_format(date_create($showbook->GO_date),"m/d/Y")}} </p>
						     </td>											   
					      </tr>

						  
						</table>
				  </td>
				</tr>
				<tr>
					<td class="reset-padding-all">
						<table width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr class="border_all">
							<th ><p class = "text-left">Container No/Seal No.</p></th>
							<th ><p class = "text-left">No of Packages</p></th>
							<th ><p class = "text-left">Description of goods</p></th>
							<th ><p class = "text-left">Gross weight</p></th>
							<th ><p class = "text-left">Measurement</p></th>
						  </tr>
						  <tr class="border_all">
			  <td width="19%" class="text-uppercase font-bold blue_acl">
			  					<p>{{$showbook->containerno}}</p>	
								<p>&nbsp;</p>
								<p>&nbsp;</p>
								<p>&nbsp;</p>
								
								
															
							</td>
							<td width="13%" class="text-uppercase font-bold blue_acl"><p>{{$showbook->package_no}}</p></td>
							<td width="44%" class="text-uppercase blue_acl">
						    <p  style="white-space: pre-wrap;" class="font-bold">{{$showbook->kind_package_no}} 						
						    </p>
						    <p class="font-bold">&nbsp;</p>
						    <p class="font-bold">&nbsp;</p>
						    <p class="font-bold">&nbsp;</p>
						    <p class="font-bold">&nbsp; </p></td>
							<td width="12%" class="text-uppercase blue_acl"><p><span class="font-bold">{{$showbook->gross_weight}}</span></p></td>
							<td width="12%" class="text-uppercase blue_acl"><p> <span class="font-bold">{{$showbook->measurement}} </span></p></td>
						  </tr>
						 
						</table>
					</td>
				</tr>
				<tr>
					<td class="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr class="text-left">
								<th><p>CARGO LOCATION: </p></th>
								<th><p></p></th>
								<th><p>REMIT PAYMENT TO: </p></th>
							</tr>
							<tr>
								<td class="text-uppercase blue_acl" width="37%">
								<p>
								<?php 
									$str =$showbook->cargo_location;
									$a1 = strpos($str,'Company:');
									$b1= strpos($str,'Address:');	
									echo substr($str,$a1+8,$b1-$a1-8)."<br>";	

									$a2 = strpos($str,'Address:');
									$b2= strpos($str,'City:');	
									echo substr($str,$a2+8,$b2-$a2-8).", ";

									$a3 = strpos($str,'City:');
									$b3= strpos($str,'State:');	
									echo substr($str,$a3+5,$b3-$a3-5).", ";

									$a4 = strpos($str,'State:');
									$b4= strpos($str,'Zip');	
									echo substr($str,$a4+6,$b4-$a4-6);

									$a5 = strpos($str,'Zip Code:');
									$b5= strpos($str,'Country');	
									echo substr($str,$a5+9,$b5-$a5-9);

									$a6 = strpos($str,'Country:');
									$b6= strpos($str,'Tel:');	
									echo substr($str,$a6+8,$b6-$a6-8).". ";

									$a7= strpos($str,'Tel:');						
									echo substr($str,$a7,strlen($str)-$a7);	
								?>
							</p>
								<!---<p class="font-bold">ITS TERMINAL</p>
							    <p class="font-bold">FIRM CODE: Y309. PIER G AVE</p>
							    <p class="font-bold">LONG BEACH, CA 90820 t: 562-1241736477</p></td>
							    -->
								</td>
							  <td width="26%" >&nbsp;</td>
								<td width="37%" class="text-uppercase blue_acl" >
								<p>
									<?php 
									$str =$showbook->remit_payment;
									$a1 = strpos($str,'Company:');
									$b1= strpos($str,'Address:');	
									echo substr($str,$a1+8,$b1-$a1-8)."<br/>";																

									$a2 = strpos($str,'Address:');
									$b2= strpos($str,'City:');	
									echo substr($str,$a2+8,$b2-$a2-8).", ";

									$a3 = strpos($str,'City:');
									$b3= strpos($str,'State:');	
									echo substr($str,$a3+5,$b3-$a3-5).", ";

									$a4 = strpos($str,'State:');
									$b4= strpos($str,'Zip');	
									echo substr($str,$a4+6,$b4-$a4-6)."<br/>";


									$a7= strpos($str,'Tel:');						
									echo substr($str,$a7,strlen($str)-$a7);	
								?>
							</p>
								</td>
							</tr>
						 
						</table>
					</td>
				</tr>
				<tr>
					<td class ="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="58%" class ="reset-padding-all">
									<table width="91%" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="5%"><p>1.<p></td>
								
											<td width="95%" class="text-uppercase" ><p>personal checks will not be accepted </p>
										    <p>cashier's check, money</p>
										    <p>order and company check only.</p></td>
										</tr>
										<tr>
											<td width="5%"><p>2.</p></td>
								
											<td width="95%" class="text-uppercase" ><p>we will release the freight to you upon receiving your full payment and your endorsed original bill of lading</p></td>
										</tr>
										<tr>
											<td width="5%"><p>3.</p></td>
								
											<td width="95%" class="text-uppercase" ><p>prior to cargo pick-up consignee must clear</p>
										    <p>custom and confirm freight release with pier/cfs</p></td>
										</tr>
										<tr>
											<td width="5%"><p>4.</p></td>
								
											<td width="95%" class="text-uppercase" ><p>for lcl shipment before pick up cargo. please contact local warehouse for any additional charges</p></td>
										</tr>
										<tr>
											<td width="5%"><p>5.</p></td>
								
											<td width="95%" class="text-uppercase" ><p>please pick-up your cargo a.s.a.p to void unnecessary charges.</p></td>
										</tr>
							 
									</table>
								</td>
					
								<td width="42%" class="font-bold reset-padding-all" >
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="53%" class="text-uppercase">freight collect:</td>
								
											<td width="19%" class="text-uppercase" ><p>$</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->freight_collect}}</td>
										</tr>
										<tr>
											<td width="53%" class="text-uppercase">handling fee:</td>
								
											<td width="19%" class="text-uppercase" ><p>$</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->handling_fee}}</td>
										</tr>
										<tr>
											<td width="53%" class="text-uppercase">ams fee :</td>
								
											<td width="19%" class="text-uppercase" ><p>$</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->ams_fee}}</td>
										</tr>
										<tr>
											<td width="53%" class="text-uppercase">d.d.c:</td>
								
											<td width="19%" class="text-uppercase" ><p>$</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->ddc}}</td>
										</tr>
										<tr>
											<td width="53%" class="text-uppercase">demurrage:</td>
								
											<td width="19%" class="text-uppercase" ><p>$</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->demurrage}}</td>
										</tr>
										<tr>
										  <td class="text-uppercase">inland freight:</td>
										  <td class="text-uppercase">$</td>
										  <td class="text-right blue_acl">{{$showbook->inland_freight}}</td>
									  </tr>
										<tr>
										  <td class="text-uppercase">custom clearance:</td>
										  <td class="text-uppercase">$</td>
										  <td class="text-right blue_acl">{{$showbook->custom_clearance}}</td>
									  </tr>
									  <tr>
										  <td class="text-uppercase">custom duty:</td>
										  <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->custom_duty}}</td>
									  </tr>
									  <tr>
										  <td class="text-uppercase">custom bound:</td>
										  <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->custom_bond}}</td>
									  </tr>
									  <tr>
										  <td class="text-uppercase">examination fee:</td>
										  <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->examination_fee}}</td>
									  </tr>
									  <tr>
										  <td>CFS In &amp; Out Charges </td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->cfs_charges}}</td>
									  </tr>
									  <tr>
										  <td>T.H.C FEE:</td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->thc_fee}}</td>
									  </tr>
									  <tr>
										  <td>Origin Custom Charges:</td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->origin_charges}}</td>
									  </tr>
									  <tr>
										  <td>Chassis Charges:</td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->chassis_charges}}</td>
									  </tr>
									  <tr>
										  <td>Pier Pass Charges:</td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->pier_pass_charges}}</td>
									  </tr>
									  <tr>
										  <td>I.T Entry Charges:</td>
									    <td class="text-uppercase" >$</td>
										  <td class="text-right blue_acl">{{$showbook->IT_entry_charges}}</td>
									  </tr>
									  
										
							 
									</table>
								
								</td>
							</tr>
							<br/>
							<tr>
								<td width="58%">
								
									<p class="font-bold" style="font-size: 15px">Prepare By: <font color="#033264">{{$showbook->prepare_by}} </font></p>
								
								</td>
					
								<td width="42%" class="font-bold reset-padding-all" >
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="53%" class="text-uppercase">Amount due</td>
											<td width="19%" class="text-uppercase" ><p class="font-bold">$usd</p></td>
											<td width="28%" class="text-right blue_acl">{{$showbook->amount_due}}</td>
										</tr>
									</table>
								</td>
							</tr>
						 
						</table>
					</td>
				</tr>
			</tbody>
        </table>
			<div class = "border_top footer-print hidden">
			<div width="50%" style="float:left;text-align:left;">
				<p>{{Auth::user()->address}}</p>
				<p>{{Auth::user()->city}}, {{Auth::user()->zip_code}} {{Auth::user()->country}}</p>
				<p>Website: www.shipping.americancontainerline.com</p>
			</div>
			<div width="50%" style="float:right; text-align:right;">
				<p>Tel: {{Auth::user()->phone}}</p>
				<p>Fax: {{Auth::user()->fax}}</p>
				<p>Email: {{Auth::user()->email}}</p>
			</div>
		</div>
        <input type="button" class="hide" onClick="window.print()" class="hide" value="Print"/>
    </div>
</body>
</html>