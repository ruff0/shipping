<!DOCTYPE html>
<html moznomarginboxes mozdisallowselectionprint>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel='stylesheet' type='text/css' media="all" href="{{url('public/shippingtemplate/css/print-table/reset.css')}}"/>
<link rel="stylesheet" type="text/css" media="all" href="{{url('public/shippingtemplate/css/print-table/style.css')}}"/>
<title>BILL OF LADING</title>
<!-- Description, Keywords and Author -->
<meta name="description" content="SERENCO JSC"/>
<meta name="keywords" content="CORE BANKING, BANKING SOFTWARE"/>
<meta name="author" content="serenco jsc">
<style type="text/css">#page-wrap table tbody tr .reset-padding-all table {
}
p{
	font-size:10px;
}
</style>
</head>

<body>
	<div id="page-wrap">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td colspan="2" class="reset-padding-all border_bottom">
					  <table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr class = "" >
								<td width="43%" valign="middle" ><img src="{{url('public/shippingtemplate/images/acl.png')}}" alt="ACL" width="300"/></td>
						    <td width="28%" valign="middle" class = "border_right border_left font-bold"><h2 class="tex-center">BILL OF LADING</h2></td>
							  <td width="29%" valign="middle" ><h2 class="text-right font-bold"><?php if($showbook->type == 0) 
							  { 
							  	echo "ORIGINAL";
							  }
							  else{
							  	echo "NON-NEGOTIABLE";
							  }
							   ?></h2></td>
							</tr>
						</table>
				    </td>
				</tr>
				<tr class = "border_bottom">
					<td width="50%" >
						<p class = "fix-tex-zise font-bold">Shipper/exporter (complete name and address)</p>
						<p class = "text-uppercase blue_acl">
						<?php 
		
						$str =$showbook->shipper;					
						$a= strpos($str,'Contact Name:');
						$b= strpos($str,'Address:');
						
						echo substr($str,$a+13,$b-$a-13)."<br/>";

						$str =$showbook->shipper;					
						$a1= strpos($str,'Address:');
						$b1= strpos($str,'Company:');
						
						echo substr($str,$a1+8,$b1-$a1-8)."<br/>";

						$str =$showbook->shipper;					
						$a2= strpos($str,'City:');
						$b2= strpos($str,'State:');
						
						echo substr($str,$a2+5,$b2-$a2-5).", ";

						$str =$showbook->shipper;					
						$a3= strpos($str,'State:');
						$b3= strpos($str,'Zip Code:');
						
						echo substr($str,$a3+6,$b3-$a3-6);

						$str =$showbook->shipper;					
						$a4= strpos($str,'Zip Code:');
						$b4= strpos($str,'Country:');
						
						echo substr($str,$a4+9,$b4-$a4-9);


						$str =$showbook->shipper;					
						$a5= strpos($str,'Country:');
						$b5= strpos($str,'Phone:');
						
						echo substr($str,$a5+8,$b5-$a5-8);

						$str =$showbook->shipper;					
						$a6= strpos($str,'Phone:');
						$b6= strpos($str,'Fax:');
						
						echo "Tel:".substr($str,$a6+6,$b6-$a6-6);
						?>

					</td>
					<td width="50%" class = "border_left reset-padding-all fix_border_size">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr class = "border_bottom">
								<td width="50%" ><p class="fix-tex-zise font-bold">Booking No.</p>
							    <p class="blue_acl">{{$book->booking_no}}</p></td>
								<td width="50%" class = "border_left font-bold"><p  class="fix-tex-zise">B/L No.</p>
							    <p class="blue_acl">{{$book->BL_no}}</p></td>
							</tr>
							<tr >
								<td colspan="2"><p  class="fix-tex-zise font-bold">Export references</p>
							    <p class="blue_acl">{{$book->export_no}}</p></td>
							</tr>
							
						</table>
					</td>
				</tr>
				<tr class = "border_bottom">
					<td width="50%" >
						<p  class="fix-tex-zise font-bold"> Consignee(complete name and address)</p>
					<p class="text-uppercase blue_acl">
						<?php 
						$str =$showbook->consignee;
											
						$a1 = strpos($str,'Company:');
						$b1= strpos($str,'Address:');	
						echo substr($str,$a1+8,$b1-$a1-8)."<br>";
						$a2 = strpos($str,'Address:');
						$b2= strpos($str,'City:');	
						echo substr($str,$a2+8,$b2-$a2-8)."<br>";
						$a3 = strpos($str,'City:');
						$b3= strpos($str,'Country:');	
						echo substr($str,$a3+5,$b3-$a3-5);
						$a= strpos($str,'Country:');						
						echo substr($str,$a+8,strlen($str)-$a-8);	
						?>
					</p>
						<!--<p>CO TY TNHH THUONG MAI MINH PUONG </p>
						<p>123 NGUYEN DUY, PHUONG 14, QUAN 8</p>
						<p>Tp HO CHI MINH, VIETNAM</p>
						-->
					</td>
					<td width="59%" class = "border_left fix_border_size reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							
							<tr>
								<td height="44" colspan="2" >
									<p  class="fix-tex-zise font-bold">Forwarding agent - references (F.M.C) No.</p>									
								</td>
							</tr>
							<tr class = "border_top">
								<td width="50%"  class="fix-tex-zise">
									<p class= "fix-tex-zise font-bold">Point and Country of Origin</p>
									<p class= "fix-tex-zise blue_acl">  <?php echo substr($showbook->place_receipt,-2); ?> </p>
								</td>
								<td width="50%" class= "border_left  fix-tex-zise">
									<p class= "fix-tex-zise ">Estimate Time Arrival</p>
									<p class= "fix-tex-zise blue_acl">{{date_format(date_create($book->date_export),"m/d/Y") }}</p>
								</td>
							</tr>
							
						</table>
					</td>
				</tr>
				<tr class = "border_bottom">
					<td width="50%" class = " reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							
							<tr>
								<td height="143" colspan="2" >
									<p  class="fix-tex-zise font-bold">Notify Party (complete name and address)</p>
									<p class="font-bold">(SAME AS CONSIGNEE)</p>
									<p class="text-uppercase">
										
									</p>
									
								</td>
							</tr>
							<tr class = "border_top">
								<td width="60%">
									<p  class="fix-tex-zise font-bold">Precarriage by</p>
								</td>
								<td width="40%" class= "border_left fix_border_size">
									<p  class="fix-tex-zise font-bold">Place of receipt</p>
									<p class="blue_acl">{{$showbook->place_receipt}}</p>
								</td>
							</tr>
							
						</table>
					</td>
					<td width="50%" class = "border_left fix_border_size">
					<p  class="fix-tex-zise font-bold">For Delivery please present to :</p>
					<p class="blue_acl">{{$showbook->delivery}} </p>
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<p>&nbsp;</p></td>
					
				</tr>
				<tr class = "border_bottom">
					<td class = "reset-padding-all" width="50%">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">	
							<tr width = "60%">
								<td width="60%" class = "reset-padding-all" >
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="64%"  ><p class="fix-tex-zise font-bold">Vessel</p></td>
											<td width="36%"  ><p class="fix-tex-zise font-bold">Voy No.</p></td>
										</tr>
										<tr>
											<td width="64%"><P class="fix-tex-zise">MOL CONTINUITY</P></td>
											<td width="36%"><P  class="fix-tex-zise">021W</P></td>
										</tr>
									</table>
								</td>
								<td width="40%"  class = "border_left fix_border_size">
									<p  class="fix-tex-zise font-bold">Port of Loading</p>
									<p class="blue_acl">{{$showbook->place_receipt}}</p>
									
								</td>
							</tr>
						</table>
					</td>
					<td width="50%" class ="border_left fix_border_size fix-tex-zise font-bold">Loading Pier/Terminal</td>
				</tr>
				<tr class = "border_bottom">
					<td class = "reset-padding-all" width="50%">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">	
							<tr>
								<td width="60%" >
									<p  class="fix-tex-zise">Port of Discharges</p>
									<p class="fix-tex-zise blue_acl">{!! $showbook->port_discharge !!}</p>
								</td>
								<td width="40%"  class = "border_left fix_border_size">
									<p  class="fix-tex-zise font-bold">Place of Delivery</p>
									<p class="fix-tex-zise text-uppercase blue_acl">{!! $showbook->final_dest !!}</p>
									
								</td>
							</tr>
						</table>
					</td>
					<td width="50%" class ="border_left fix_border_size fix-tex-zise font-bold">Type of Move</td>
				</tr>
				<tr class = "border_bottom">
					<td colspan="2" class ="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">	
							<tr>
								<td width="30%" valign="bottom" >
									<p class="fix-tex-zise font-bold">CARRIER'S RECEIPT</p>
									
								</td>
								<td width="70%" valign="bottom"  class = "border_left fix_border_size">
								  <p class="fix-tex-zise font-bold">PARTICULARS FURNISHED By - CARRIER NOT RESPONSIBLE</p>
									
									
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class = "border_bottom">
					<td colspan="2" class ="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">	
							<tr>
								<td width="20%" class="border_right"><p  class="fix-tex-zise font-bold">Container No/Seal No.</p></td>
								<td width="10%" class="border_right fix_border_size" ><p  class="fix-tex-zise font-bold">No of Packages</p></td>
								<td width="40%" ><p  class="fix-tex-zise font-bold">Kind of Packages, description of goods</p></td>
								<td width="10%" class="border_left" ><p  class="fix-tex-zise font-bold">Gross Weight</p></td>
								<td width="20%" class="border_left" ><p  class="fix-tex-zise font-bold">Measurement</p></td>
							
							</tr>
							<tr>
								<td width="20%" class ="border_right"><blockquote>
								  <p class="blue_acl">{{$showbook->containerno}}</p>
								  
							    </blockquote></td>
								<td width="10%" class="border_right  fix_border_size" ><p class="blue_acl">{{$showbook->package_no}}</p>
							    <p>&nbsp; </p></td>
							  <td width="40%" >
							  	<p class="blue_acl" style="white-space: pre-wrap;"> <?php echo $showbook->kind_package_no;
							  	?>
							  	</p>
							  </td>
								<td width="10%" class="border_left blue_acl" ><p>{{$showbook->gross_weight}} </p></td>
								<td width="20%" class="border_left blue_acl" ><p>{{$showbook->measurement}} </p></td>
							
							</tr>
							
						</table>
				  </td>
				</tr>
				<tr class = "border_bottom fix_border_size">
					<td colspan="2" class ="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">	
							<tr  class="fix-tex-zise">
							  <td width="30%" class = "border_right fix_border_size" ><p class= "fix-tex-zise">Freight &amp; Charges</p></td>
								<td width="20%" class="border_right font-bold" >Rate</td>
								<td width="20%" ><p class= "fix-tex-zise font-bold">Unit</p>
							    <p>&nbsp;</p>
						      <p>&nbsp;</p></td>
								<td width="10%" class="border_left" ><p class= "fix-tex-zise font-bold">Prepaid</p></td>
								<td width="20%" class="border_left" ><p class= "fix-tex-zise font-bold">Collect</p></td>
							</tr>
							
						</table>
				  </td>
				</tr>
				<tr>
					<td width="50.2%" class ="reset-padding-all">
						<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="fix-tex-zise">
							<tr class = "border_bottom tex-line-height">
								<td width="60%"  class="border_right fix_border_size">
                                <p class= "fix-tex-zise font-bold">Declared Value Charges</p>
							    <p class= "fix-tex-zise font-bold">(see clause 10)</p>
                                <p class= "fix-tex-zise font-bold">Declared value of US $</p>
                                </td>
								<td width="40%" class="border_right " >
                                <p class= "fix-tex-zise font-bold">Total Prepaid</p>
							    <p>&nbsp;</p>
							    <p>&nbsp;</p>
                                <p>&nbsp;</p>

								</td>
				              </tr>
							<tr class = "border_bottom tex-line-height">
								<td width="60%" class = "border_right fix_border_size"><p class= "fix-tex-zise font-bold">Number of Original B(s)/L</p>
							    <p class= "fix-tex-zise blue_acl ">{{$showbook->number_original}}</p></td>
								<td width="40%" class="border_right" ><p class= "fix-tex-zise font-bold">Total collect</p></td>
							</tr>
							<tr class = " border_bottom tex-line-height">
								<td width="60%" class = "border_right fix_border_size"><p class= "fix-tex-zise font-bold">Place of issue</p>
							    <p class= "fix-tex-zise blue_acl">{{$showbook->place_issue}}</p></td>
								<td width="40%" class="border_right" ><p class= "fix-tex-zise font-bold">Date Laden on Board</p>
							    <p class= "fix-tex-zise blue_acl">{{date_format(date_create($book->date_laden),"m/d/Y") }}</p></td>
							</tr>
							<tr>
								<td width="60%" class=" tex-line-height">
                                	<p class= "fix-tex-zise font-bold">*Applicable only when document used as Combined Transport Bill of Lading</p>
                                	<p class= "fix-tex-zise font-bold">American Container Line Bond No 055912</p>
						      </td>
								<td width="40%">
								</td>
						 	</tr>
													
						</table>
					</td>
					<td width="50%">
						
									<p class = "tex-indent  fix-tex-zise  tex-line-height" >&nbsp;</p>
									<p class = "tex-indent  fix-tex-zise  tex-line-height" style="font-size: 8px;">Received in apparent good order and condition, unless otherwise indicated herein, the total number of goods, container, packages or other unit said to contain the cargo herein metioned, to be carried subject to all the terms and conditions provided for on the face nad back of this Bill of Lading by the vessel named herein or any substitute at the Carrier's option and/or other means of transport from the place of reciept to the place of delivery</p>
					  				<p class = "tex-indent fix-tex-zise  tex-line-height" style="font-size: 8px;">One of the signed Bills of Lading must be surrendered duly endorsed in exchange for the goods or delivery order. On presentation for this document duly endorsed to the Delivery Agent by the Holder, the right and liabilities arising in accordance with the terms hereof shall, without prejudice to any rule of common law or statute rendering them biding on the Holder, become binding in all respects between the Carrier and the Holder as though the contact evidenced hereby had been made between them.</p>
									<p class = "tex-indent fix-tex-zise  tex-line-height" style="font-size: 8px;">In witness whereof, the undersigned has signed three (3) Bills of Lading, all of this tenor and date, one of which being accomplished the others to stand void</p>
									
									<h1 class ="tex-center" style = "font-size:12px;margin-top: 10px; font-weight: bold">AMERICAN CONTAINER LINE AS AGENTS FOR THE CARRIER</h1>
									
									<div class = "tex-center border_top" style = "width:80%;margin: 0 auto; font-weight: bold"><p class= "fix-tex-zise">As Agent(s) only</p></div>
						
					</td>
				</tr>																							 							
			</tbody>
        </table>
				
        <input type="button" class="hide" onClick="window.print()" class="hide" value="Print"/>
    </div>
</body>
</html>